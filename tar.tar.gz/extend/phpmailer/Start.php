<?php
/**
 * Created by PhpStorm.
 * User: A
 * Date: 2019/12/10
 * Time: 16:56
 */

namespace phpmailer;

require_once('Exception.php');
require_once('PHPMailer.php');
require_once('SMTP.php');


class Start{

}