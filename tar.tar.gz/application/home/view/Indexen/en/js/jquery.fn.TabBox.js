// JavaScript Document

function fnTabBoxShow(Focus,Hide,Show){
	$(Focus).siblings().removeClass("focus");
	$(Focus).addClass("focus");
	$(".TabHide"+Hide).hide();
	$("#TabShow"+Show).show();
};

function fnTabBoxSlide(Focus,Hide,Show){
	$(Focus).siblings().removeClass("focus");
	$(Focus).addClass("focus");
	$(".TabHide"+Hide).hide();
	$("#TabShow"+Show).slideDown("fast");
};

function fnTabBoxFade(Focus,Hide,Show){
	$(Focus).siblings().removeClass("focus");
	$(Focus).addClass("focus");
	$(".TabHide"+Hide).hide();
	$("#TabShow"+Show).fadeIn("fast");
};



